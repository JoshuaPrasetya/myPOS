import { NgModule } from '@angular/core';
import { ArrayFilterPipe } from './array-filter/array-filter';
@NgModule({
	declarations: [ArrayFilterPipe],
	imports: [],
	exports: [ArrayFilterPipe]
})
export class PipesModule {}
